<?php
if (defined('WOOCOMMERCE_VERSION')):
    // require_once NOO_FRAMEWORK . '/add-ons/package-addon/job-package-addon-functions.php';
    require_once NOO_FRAMEWORK . '/add-ons/package-addon/job-package-addon-type.php';
    require_once NOO_FRAMEWORK . '/add-ons/package-addon/job-package-addon-process.php';
endif;