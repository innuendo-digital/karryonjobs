<?php

require_once NOO_FRAMEWORK . '/resume/functions.php';
require_once NOO_FRAMEWORK . '/resume/init.php';
require_once NOO_FRAMEWORK . '/resume/admin.php';
require_once NOO_FRAMEWORK . '/resume/admin-settings.php';
require_once NOO_FRAMEWORK . '/resume/admin-resume-list.php';
require_once NOO_FRAMEWORK . '/resume/admin-resume-edit.php';
require_once NOO_FRAMEWORK . '/resume/resume-default-fields.php';
require_once NOO_FRAMEWORK . '/resume/resume-custom-fields.php';
require_once NOO_FRAMEWORK . '/resume/resume-custom-fields-package.php';
require_once NOO_FRAMEWORK . '/resume/resume-query.php';
require_once NOO_FRAMEWORK . '/resume/resume-viewable.php';
require_once NOO_FRAMEWORK . '/resume/resume-viewable-contact.php';
require_once NOO_FRAMEWORK . '/resume/resume-viewable-job-package.php';
require_once NOO_FRAMEWORK . '/resume/resume-template.php';
require_once NOO_FRAMEWORK . '/resume/resume-template-shortcodes.php';
require_once NOO_FRAMEWORK . '/resume/resume-posting.php';
require_once NOO_FRAMEWORK . '/resume/resume-posting-action.php';
require_once NOO_FRAMEWORK . '/resume/resume-posting-package.php';
require_once NOO_FRAMEWORK_ADMIN . '/noo_resume.php';
