jQuery( document ).ready( function ( $ ) {
	
} );

