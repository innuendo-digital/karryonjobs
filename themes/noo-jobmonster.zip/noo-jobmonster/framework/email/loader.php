<?php

require_once NOO_FRAMEWORK . '/email/template_fields.php';
require_once NOO_FRAMEWORK . '/email/functions.php';
require_once NOO_FRAMEWORK . '/email/setting_templates.php';