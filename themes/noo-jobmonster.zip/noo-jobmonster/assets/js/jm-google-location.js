var infoBox;
(function($){
	"use strict";
	function noo_job_map_initialize(){
	}
	// google.maps.event.addDomListener(window, 'load', noo_job_map_initialize);
})(jQuery);